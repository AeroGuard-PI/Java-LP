package org.example;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    static void main() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("======= CADASTRO: =======");

        System.out.println("Digite o seu nome: ");
        String nome = scanner.nextLine();

        System.out.println("Digite o seu sobrenome: ");
        String sobrenome = scanner.nextLine();

        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("Digite o sua data de nascimento (dd/mm/yyyy): ");
        String dataNascimento = scanner.nextLine();
        LocalDate dataFormatada = LocalDate.parse(dataNascimento, formatador);

        System.out.println("Digite o código da sua empresa: ");
        String codigoEmpresa = scanner.nextLine();

        System.out.println("Digite o seu email: ");
        String email = scanner.nextLine();

        System.out.println("Digite o seu telefone: ");
        String telefone = scanner.nextLine();

        System.out.println("Digite o seu CPF: ");
        String cpf = scanner.nextLine();

        Cadastro novoCadastrar = new Cadastro(nome, sobrenome, dataFormatada, codigoEmpresa, email, telefone, cpf);
        novoCadastrar.exibrCadastro();

    }
}
