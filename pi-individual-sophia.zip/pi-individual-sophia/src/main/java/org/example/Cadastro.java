package org.example;

import java.time.LocalDate;
import java.util.Date;

public class Cadastro {

    String nome;
    String sobrenome;
    LocalDate dataDeNascimento;
    String empresa;
    String email;
    String telefone;
    String cpf;

    Cadastro(String nome, String sobrenome, LocalDate dataDeNascimento, String empresa, String email, String telefone, String cpf){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.dataDeNascimento = dataDeNascimento;
        this.empresa = empresa;
        this.email = email;
        this.telefone = telefone;
        this.cpf = cpf;
    }


    void exibrCadastro(){
        String mensagem = """
               Nome: %s
               Sobrenome: %s
               Data de Nascimento: %s
               Código empresa: %s
               Email: %s
               Telefone: %s
               CPF: %s
               """.formatted(nome, sobrenome, dataDeNascimento,empresa, email, telefone, cpf);

        System.out.println(mensagem);
    }


}
