package school.sptech;
import javax.swing.*;
import java.sql.SQLOutput;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.Scanner;
public class cadastroLogin {

    void main() {
        System.out.println("""
                
                
                
      
                ========================================
                ====     BEM-VINDO AO AEROGUARD     ====
                ========================================""");
        menu();
    }

        void menu() {
        Scanner leitor = new Scanner(System.in);
        System.out.println("Cadastrar-se (1) | Login (2)");
        Integer menu = leitor.nextInt();
        if (menu == 1) {
            cadastrar();
        }
        else if (menu == 2) {
            login();
        }
        else {
            System.out.println("Digite uma das opções:");
            menu();
        }

    }

    ArrayList<String> nomes = new ArrayList<>();
    ArrayList<String> emails = new ArrayList<>();
    ArrayList<String> senhas = new ArrayList<>();
    ArrayList<String> funcoes = new ArrayList<>();

    void cadastrar() {
        Scanner leitor = new Scanner(System.in);
        System.out.println("CADASTRO: \n");
        System.out.println("Nome:");
        String nome = leitor.nextLine();
        System.out.println("Email:");
        String email = leitor.nextLine();
        System.out.println("Senha:");
        String senha = leitor.nextLine();
        System.out.println("Função que exerce:");
        String funcao = leitor.nextLine();
        if (!funcao.equalsIgnoreCase("analista") && !funcao.equalsIgnoreCase("gestor")) {
            System.out.println("Função desconhecida");
            cadastrar();
        }
        if (nome.isEmpty()|| email.isEmpty() || senha.isEmpty() || funcao.isEmpty()) {
            System.out.println("Preencha todos os campos corretamente");
            cadastrar();
        }
        else {
            nomes.add(nome);
            emails.add(email);
            senhas.add(senha);
            funcoes.add(funcao);
            System.out.println("Cadastro Realizado!");
            System.out.println("\n\n\n\n\n\n\n\n\n");
            menu();
        }
    }

    void login() {
        Scanner leitor = new Scanner(System.in);
        System.out.println("LOGIN:  \n");
        System.out.println("Email:");
        String email = leitor.nextLine();
        int indice = emails.indexOf(email);
        if ( indice == -1) {
            System.out.println("Conta não encontrada");
            menu();
        }
        else {
            System.out.println("Senha: ");
            String senha = leitor.nextLine();
            if ( senhas.get(indice).equals(senha)) {
                System.out.println("Login Realizado!");
            }
            else {
                System.out.println("Senha errada");
                menu();
            }
        }

    }

}
